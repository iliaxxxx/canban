# 🚀 START HERE

## Добро пожаловать в миграцию на Claude!

Этот файл поможет вам начать за 2 минуты.

---

## ⚡ Супер-быстрый старт

```bash
# 1. Скачайте и распакуйте
unzip psychoplan-ai-kanban-claude.zip
cd psychoplan-ai-kanban-claude

# 2. Получите API ключ на https://console.anthropic.com/
# 3. Запустите миграцию
chmod +x migrate.sh
./migrate.sh

# 4. Добавьте ключ
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env.local

# 5. Запустите
npm install
npm run dev

# ✨ Готово!
```

---

## 📚 Какой файл читать?

### Если спешите (5 мин)
→ **QUICKSTART.md**

### Если хотите понять всё (15 мин)
→ **SUMMARY.md**

### Если нужны примеры кода (20 мин)
→ **EXAMPLES.md**

### Если используете Claude Code (5 мин)
→ **CLAUDE_CODE_GUIDE.md**

### Если хотите полную картину (30 мин)
→ **INDEX.md** (навигация по всем файлам)

---

## 🎯 Что внутри архива?

```
psychoplan-ai-kanban-claude/
├── services/claudeService.ts  ← Новый AI сервис
├── migrate.sh                 ← Скрипт миграции
├── package.json               ← Обновлённые зависимости
├── README.md                  ← Полная документация
└── ... все остальные файлы
```

---

## ✅ Чеклист

- [ ] Скачал **psychoplan-ai-kanban-claude.zip**
- [ ] Прочитал **QUICKSTART.md** или **SUMMARY.md**
- [ ] Получил API ключ на console.anthropic.com
- [ ] Запустил миграцию
- [ ] Всё работает! 🎉

---

## 🆘 Помощь

**Не работает?**
→ См. раздел Troubleshooting в **QUICKSTART.md**

**Нужны примеры?**
→ Откройте **EXAMPLES.md**

**Хотите автоматизировать?**
→ Откройте **CLAUDE_CODE_GUIDE.md**

---

## 💡 Совет

Начните с **QUICKSTART.md** - там всё по шагам!

**Удачи! 🚀**

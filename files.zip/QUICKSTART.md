# ⚡ Быстрый старт: Миграция на Claude

## 📦 Что вы получили

В архиве `psychoplan-ai-kanban-claude.zip` находится полностью обновлённый проект:

- ✅ **claudeService.ts** - новый AI сервис на Claude Sonnet 4
- ✅ **package.json** - обновлённые зависимости
- ✅ **migrate.sh** - скрипт автоматической миграции
- ✅ **README.md** - документация
- ✅ **MIGRATION_GUIDE.md** - подробный гайд
- ✅ **TECHNICAL_DETAILS.md** - технические детали API

---

## 🚀 Два способа миграции

### Способ 1: Автоматическая миграция (рекомендуется)

```bash
# 1. Распакуйте архив
unzip psychoplan-ai-kanban-claude.zip -d psychoplan-claude

# 2. Перейдите в директорию
cd psychoplan-claude

# 3. Запустите скрипт миграции
chmod +x migrate.sh
./migrate.sh

# 4. Добавьте ваш Anthropic API ключ в .env.local
# ANTHROPIC_API_KEY=sk-ant-...

# 5. Установите зависимости
npm install

# 6. Запустите проект
npm run dev
```

### Способ 2: Ручная миграция

```bash
# 1. Скопируйте claudeService.ts в services/
cp claudeService.ts services/

# 2. Замените импорты вручную в файлах:
# - App.tsx
# - components/AIGenerator.tsx
# - components/CompetitorView.tsx
# - components/CarouselMaker.tsx
# 
# Замените: geminiService → claudeService

# 3. Удалите старый сервис
rm services/geminiService.ts

# 4. Обновите .env.local
# ANTHROPIC_API_KEY=your_key_here

# 5. Обновите package.json (уже в архиве)

# 6. Установите зависимости
npm install

# 7. Запустите проект
npm run dev
```

---

## 🔑 Получение API ключа

1. Зайдите на https://console.anthropic.com/
2. Зарегистрируйтесь или войдите
3. Перейдите в раздел **API Keys**
4. Нажмите **Create Key**
5. Скопируйте ключ и вставьте в `.env.local`:

```env
ANTHROPIC_API_KEY=sk-ant-api03-xxx...
```

---

## ✅ Проверка миграции

После запуска проверьте:

1. **Генерация идей** - откройте AI Generator
2. **Создание сценариев** - попробуйте generate script
3. **Карусели** - проверьте Carousel Maker
4. **Анализ конкурентов** - откройте Competitor View

Если всё работает - миграция прошла успешно! 🎉

---

## 📚 Документация

- **README.md** - общая информация о проекте
- **MIGRATION_GUIDE.md** - подробный гайд по миграции
- **TECHNICAL_DETAILS.md** - технические детали изменений API

---

## 🐛 Проблемы?

**Не генерирует контент:**
→ Проверьте API ключ в `.env.local`

**Ошибка "AI service is not configured":**
→ Убедитесь, что переменная `ANTHROPIC_API_KEY` установлена

**Ошибка импорта:**
→ Убедитесь, что все импорты обновлены на `claudeService`

**Таймауты:**
→ Claude может работать до 60 секунд, это нормально

---

## 💰 Стоимость

Claude Sonnet 4:
- Input: $3.00 / 1M tokens
- Output: $15.00 / 1M tokens

Для типичного использования (генерация контента):
- ~500-1000 токенов на запрос
- ~$0.02-0.05 за генерацию 4 идей

**Совет:** Начните с минимального пополнения ($5-10) для тестирования.

---

## 🎯 Следующие шаги

1. ✅ Запустите миграцию
2. ✅ Протестируйте все функции
3. ✅ Сравните качество с Gemini
4. 📖 Изучите документацию для оптимизации

**Готово!** Ваш проект теперь работает на Claude Sonnet 4 🚀

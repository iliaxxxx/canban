# 🚀 Гайд по миграции с Gemini на Claude Code

## 📋 Обзор изменений

Проект **psychoplan-ai-kanban** полностью перенесён с Google Gemini API на Anthropic Claude API.

### Что изменилось:

1. **API Provider**: Google Gemini → Anthropic Claude
2. **Модель**: `gemini-2.5-flash` → `claude-sonnet-4-20250514`
3. **SDK**: `@google/genai` → `@anthropic-ai/sdk`
4. **Переменная окружения**: `GEMINI_API_KEY` → `ANTHROPIC_API_KEY`

---

## 🔧 Шаги миграции

### 1️⃣ Установите новые зависимости

```bash
# Удалите старый node_modules и package-lock.json
rm -rf node_modules package-lock.json

# Установите новые зависимости
npm install
```

### 2️⃣ Обновите переменные окружения

**Старый `.env.local`:**
```env
GEMINI_API_KEY=your_gemini_key_here
```

**Новый `.env.local`:**
```env
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

**Где взять API ключ Anthropic:**
1. Зарегистрируйтесь на https://console.anthropic.com/
2. Перейдите в раздел API Keys
3. Создайте новый ключ
4. Скопируйте и вставьте в `.env.local`

### 3️⃣ Замените импорты в компонентах

Вам нужно заменить импорты в следующих файлах:

**`App.tsx`:**
```typescript
// Было:
import { generateContentScript, generateCarouselSlides, repurposeContent } from './services/geminiService';

// Стало:
import { generateContentScript, generateCarouselSlides, repurposeContent } from './services/claudeService';
```

**`components/AIGenerator.tsx`:**
```typescript
// Было:
import { generateContentIdeas, generateStrategicPlan } from '../services/geminiService';

// Стало:
import { generateContentIdeas, generateStrategicPlan } from '../services/claudeService';
```

**`components/CompetitorView.tsx`:**
```typescript
// Было:
import { analyzeInstagramContent, rewriteCompetitorIdea } from '../services/geminiService';

// Стало:
import { analyzeInstagramContent, rewriteCompetitorIdea } from '../services/claudeService';
```

**`components/CarouselMaker.tsx`:**
```typescript
// Было:
import { generateCarouselSlides } from '../services/geminiService';

// Стало:
import { generateCarouselSlides } from '../services/claudeService';
```

### 4️⃣ Удалите старые файлы

```bash
# Удалите старый сервис Gemini
rm services/geminiService.ts
```

### 5️⃣ Скопируйте новый claudeService.ts

Поместите файл `claudeService.ts` в директорию `services/`:

```bash
cp claudeService.ts services/claudeService.ts
```

### 6️⃣ Запустите проект

```bash
npm run dev
```

---

## ✨ Преимущества миграции на Claude

### 1. **Улучшенное качество генерации**
- Claude Sonnet 4 обладает лучшим пониманием русского языка
- Более креативные и разнообразные идеи контента
- Точнее следует инструкциям и форматам

### 2. **Лучшая структурированность**
- Более надёжная генерация JSON
- Меньше ошибок парсинга
- Стабильнее работает с большими промптами

### 3. **Гибкость**
- Расширенное context window (200K токенов)
- Возможность более детальных промптов
- Лучше справляется со сложными задачами

### 4. **Скорость и надёжность**
- Стабильная работа API
- Предсказуемое время ответа
- Меньше rate limits

---

## 🔍 Технические детали

### Изменения в API вызовах

**Gemini (старый подход):**
```typescript
const response = await ai!.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
        responseMimeType: "application/json",
        responseSchema: {...}
    }
});
```

**Claude (новый подход):**
```typescript
const response = await anthropic!.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 4096,
    messages: [
        {
            role: 'user',
            content: prompt
        }
    ]
});
```

### Обработка ответов

Claude возвращает ответы в формате `content` блоков. Мы извлекаем текстовый контент:

```typescript
const textContent = response.content.find(block => block.type === 'text');
if (textContent && textContent.type === 'text') {
    return textContent.text;
}
```

### Таймауты

Увеличены таймауты с 30 до 60 секунд, так как Claude может генерировать более качественный и детальный контент.

---

## 🧪 Тестирование

После миграции протестируйте все функции:

- ✅ Генерация идей контента (AIGenerator)
- ✅ Генерация сценариев (Content Script)
- ✅ Создание каруселей (Carousel Maker)
- ✅ Переупаковка контента (Repurpose)
- ✅ Анализ контента конкурентов (Competitor View)
- ✅ Адаптация идей конкурентов

---

## 🐛 Troubleshooting

### Ошибка: "AI service is not configured"
**Решение:** Проверьте, что `ANTHROPIC_API_KEY` правильно установлен в `.env.local`

### Ошибка: "AI request timeout"
**Решение:** Проверьте интернет-соединение. Claude может занимать до 60 секунд на сложные запросы.

### Ошибка парсинга JSON
**Решение:** Новый `claudeService` имеет улучшенную обработку JSON с fallback механизмами.

### Компонент не может найти функцию
**Решение:** Убедитесь, что все импорты обновлены с `geminiService` на `claudeService`.

---

## 📊 Сравнение производительности

| Параметр | Gemini 2.5 Flash | Claude Sonnet 4 |
|----------|------------------|-----------------|
| Качество русского | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Креативность | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Следование инструкциям | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Скорость | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Стоимость | $ | $$ |

---

## 💡 Советы по оптимизации

1. **Промпты**: Claude лучше реагирует на структурированные промпты
2. **Формат ответов**: Используйте явные инструкции по JSON формату
3. **Retry логика**: Настроена exponential backoff стратегия
4. **Кэширование**: Рассмотрите возможность кэширования частых запросов

---

## 📞 Поддержка

Если возникли проблемы с миграцией:

1. Проверьте этот гайд
2. Проверьте логи в консоли браузера
3. Убедитесь, что API ключ валидный
4. Проверьте баланс аккаунта Anthropic

---

## 🎉 Готово!

Ваш проект теперь работает на Claude Sonnet 4! Наслаждайтесь улучшенным качеством генерации контента.

**Важно:** Не забудьте удалить старый `geminiService.ts` и обновить все импорты.

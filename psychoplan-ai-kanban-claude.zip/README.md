# 🎯 PsychoPlan AI Kanban - Claude Edition

> Канбан-доска для планирования контента в соцсетях с AI-генерацией на базе Claude Sonnet 4

---

## 🚀 Быстрый старт

### Автоматическая миграция (рекомендуется)

```bash
# Запустите скрипт миграции
./migrate.sh

# Добавьте ваш API ключ в .env.local
# ANTHROPIC_API_KEY=sk-ant-...

# Установите зависимости и запустите
npm install
npm run dev
```

### Ручная миграция

См. подробный [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)

---

## 📋 Что изменилось

| До (Gemini) | После (Claude) |
|-------------|----------------|
| `@google/genai` | `@anthropic-ai/sdk` |
| `GEMINI_API_KEY` | `ANTHROPIC_API_KEY` |
| `geminiService.ts` | `claudeService.ts` |
| `gemini-2.5-flash` | `claude-sonnet-4-20250514` |

---

## 🔧 Конфигурация

**`.env.local`:**
```env
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

Получите API ключ на https://console.anthropic.com/

---

## ✨ Основные функции

- ✅ **Генерация идей контента** для Instagram, TikTok, YouTube, Telegram, Threads
- ✅ **Создание сценариев** под каждую платформу
- ✅ **Генератор каруселей** для Instagram
- ✅ **Переупаковка контента** между платформами
- ✅ **Анализ контента конкурентов**
- ✅ **Адаптация идей** под вашу нишу

---

## 📦 Структура проекта

```
psychoplan-ai-kanban/
├── services/
│   ├── claudeService.ts      # ⭐ Новый AI сервис на Claude
│   ├── firebase.ts
│   ├── groqService.ts
│   └── storageService.ts
├── components/
│   ├── AIGenerator.tsx
│   ├── CompetitorView.tsx
│   ├── CarouselMaker.tsx
│   └── ...
├── App.tsx
├── migrate.sh                # 🔄 Скрипт миграции
├── MIGRATION_GUIDE.md        # 📖 Подробный гайд
└── README.md
```

---

## 🎯 Использование claudeService

```typescript
import {
  generateContentIdeas,
  generateContentScript,
  generateCarouselSlides,
  repurposeContent,
  analyzeInstagramContent,
  rewriteCompetitorIdea
} from './services/claudeService';

// Генерация идей
const ideas = await generateContentIdeas(
  'Мотивация для предпринимателей',
  'Бизнес-коуч',
  'instagram_reels',
  'Вдохновляющий',
  'talking_head'
);

// Создание сценария
const script = await generateContentScript(task);

// Генерация карусели
const slides = await generateCarouselSlides('10 способов повысить продажи');
```

---

## 🔍 API функции

### `generateContentIdeas(topic, niche, platform, tone, reelsFormat)`
Генерирует 4 идеи контента с учётом платформы и тональности.

**Параметры:**
- `topic` - тема контента
- `niche` - ниша/роль автора (default: 'General')
- `platform` - платформа или 'all' (default: 'all')
- `tone` - тональность (default: 'neutral')
- `reelsFormat` - формат reels: 'mix' | 'scenario' | 'talking_head' (default: 'mix')

**Возвращает:** `Array<{title, description, platform}>`

---

### `generateContentScript(task)`
Создаёт детальный сценарий/текст для задачи.

**Параметры:**
- `task` - объект Task с полями {title, description, platform}

**Возвращает:** `string` - готовый сценарий

---

### `generateCarouselSlides(topic)`
Генерирует структуру карусели для Instagram (5-8 слайдов).

**Параметры:**
- `topic` - тема карусели

**Возвращает:** `Array<{title, content}>`

---

### `repurposeContent(originalTask)`
Переупаковывает контент в 2 адаптации для других платформ.

**Параметры:**
- `originalTask` - исходная задача Task

**Возвращает:** `Array<{title, description, platform}>`

---

### `analyzeInstagramContent(text)`
Анализирует контент: выделяет хук, посыл, структуру, тон.

**Параметры:**
- `text` - текст для анализа

**Возвращает:** `{hook, coreMessage, structure, tone}`

---

### `rewriteCompetitorIdea(originalText, myTopic, platform)`
Адаптирует идею конкурента под вашу тему.

**Параметры:**
- `originalText` - оригинальный текст
- `myTopic` - ваша тема
- `platform` - целевая платформа (default: 'instagram_reels')

**Возвращает:** `{title, description}`

---

## 🧪 Особенности реализации

### Надёжность
- ✅ Exponential backoff retry (3 попытки)
- ✅ Таймауты (60 секунд)
- ✅ Улучшенная обработка JSON с fallback
- ✅ Подробное логирование ошибок

### Оптимизация
- ✅ Проверка доступности API при запуске
- ✅ Безопасный парсинг JSON
- ✅ Извлечение чистого JSON из markdown блоков

---

## 📊 Преимущества Claude Sonnet 4

1. **🇷🇺 Превосходное понимание русского языка**
2. **🎨 Более креативная генерация**
3. **📝 Точное следование инструкциям**
4. **🔒 Надёжная структура JSON**
5. **💬 200K токенов контекста**

---

## 🐛 Troubleshooting

**Ошибка: "AI service is not configured"**
→ Проверьте `ANTHROPIC_API_KEY` в `.env.local`

**Ошибка: "AI request timeout"**
→ Проверьте интернет-соединение

**Не генерирует идеи**
→ Проверьте баланс аккаунта Anthropic

---

## 📄 Лицензия

MIT

---

## 🤝 Автор

Разработано с использованием Claude Sonnet 4 🚀

**Вопросы?** См. [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)
